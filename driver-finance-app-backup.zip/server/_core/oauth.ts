import { COOKIE_NAME, ONE_YEAR_MS } from "../../shared/const.js";
import type { Express, Request, Response } from "express";
import { getUserByOpenId, upsertUser } from "../db";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";
import { refreshTokenService } from "./refresh-token-service.js";

function getQueryParam(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

async function syncUser(userInfo: {
  openId?: string | null;
  name?: string | null;
  email?: string | null;
  loginMethod?: string | null;
  platform?: string | null;
}) {
  if (!userInfo.openId) {
    throw new Error("openId missing from user info");
  }

  const lastSignedIn = new Date();
  await upsertUser({
    openId: userInfo.openId,
    name: userInfo.name || null,
    email: userInfo.email ?? null,
    loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
    lastSignedIn,
  });
  const saved = await getUserByOpenId(userInfo.openId);
  return (
    saved ?? {
      openId: userInfo.openId,
      name: userInfo.name,
      email: userInfo.email,
      loginMethod: userInfo.loginMethod ?? null,
      lastSignedIn,
    }
  );
}

function buildUserResponse(
  user:
    | Awaited<ReturnType<typeof getUserByOpenId>>
    | {
        openId: string;
        name?: string | null;
        email?: string | null;
        loginMethod?: string | null;
        lastSignedIn?: Date | null;
      },
) {
  return {
    id: (user as any)?.id ?? null,
    openId: user?.openId ?? null,
    name: user?.name ?? null,
    email: user?.email ?? null,
    loginMethod: user?.loginMethod ?? null,
    lastSignedIn: (user?.lastSignedIn ?? new Date()).toISOString(),
  };
}

export function registerOAuthRoutes(app: Express) {
  // Generate Google OAuth authorization URL (Web flow)
  app.get("/api/auth/google/url", (req: Request, res: Response) => {
    try {
      console.log("[OAuth] Generating Google authorization URL for web");
      
      // Get environment variables - use WEB client ID for redirect flow
      const clientId = process.env.GOOGLE_CLIENT_ID_WEB || process.env.GOOGLE_CLIENT_ID;
      const redirectUri = process.env.GOOGLE_REDIRECT_URI;
      
      if (!clientId || !redirectUri) {
        console.error("[OAuth] Missing Google OAuth web configuration", {
          hasClientId: !!clientId,
          hasRedirectUri: !!redirectUri,
          hasClientIdWeb: !!process.env.GOOGLE_CLIENT_ID_WEB,
        });
        res.status(500).json({
          error: "OAuth configuration missing",
          details: "GOOGLE_CLIENT_ID_WEB or GOOGLE_REDIRECT_URI not configured",
        });
        return;
      }
      
      console.log("[OAuth] Using Client ID (Web):", clientId?.substring(0, 20) + "...");
      
      // Generate authorization URL
      const scope = encodeURIComponent("openid profile email");
      const state = btoa(redirectUri); // Encode redirect URI as state
      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
        `client_id=${encodeURIComponent(clientId)}&` +
        `redirect_uri=${encodeURIComponent(redirectUri)}&` +
        `response_type=code&` +
        `scope=${scope}&` +
        `state=${encodeURIComponent(state)}&` +
        `access_type=offline`;
      
      console.log("[OAuth] Authorization URL generated successfully");
      res.json({ url: authUrl });
    } catch (error) {
      console.error("[OAuth] Error generating authorization URL:", error);
      res.status(500).json({
        error: "Failed to generate authorization URL",
        details: error instanceof Error ? error.message : String(error),
      });
    }
  });

  // Generate Google OAuth authorization URL for mobile (with deep link redirect URI)
  app.get("/api/auth/google/url/mobile", (req: Request, res: Response) => {
    try {
      console.log("[OAuth] Generating Google authorization URL for mobile");
      
      // Get environment variables - use WEB client ID for redirect flow
      const clientId = process.env.GOOGLE_CLIENT_ID_WEB || process.env.GOOGLE_CLIENT_ID;
      const mobileRedirectUri = process.env.GOOGLE_REDIRECT_URI_MOBILE || 
                                 process.env.GOOGLE_REDIRECT_URI_SCHEME || 
                                 "manus20260215181436://oauth/callback";
      
      if (!clientId || !mobileRedirectUri) {
        console.error("[OAuth] Missing Google OAuth mobile configuration", {
          hasClientId: !!clientId,
          hasMobileRedirectUri: !!mobileRedirectUri,
        });
        res.status(500).json({
          error: "OAuth mobile configuration missing",
          details: "GOOGLE_CLIENT_ID or GOOGLE_REDIRECT_URI_MOBILE not configured",
        });
        return;
      }
      
      console.log("[OAuth] Mobile redirect URI:", mobileRedirectUri);
      
      // Generate authorization URL with mobile redirect URI
      const scope = encodeURIComponent("openid profile email");
      const state = btoa(mobileRedirectUri); // Encode redirect URI as state
      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
        `client_id=${encodeURIComponent(clientId)}&` +
        `redirect_uri=${encodeURIComponent(mobileRedirectUri)}&` +
        `response_type=code&` +
        `scope=${scope}&` +
        `state=${encodeURIComponent(state)}&` +
        `access_type=offline`;
      
      console.log("[OAuth] Mobile authorization URL generated successfully");
      res.json({ url: authUrl, redirectUri: mobileRedirectUri });
    } catch (error) {
      console.error("[OAuth] Error generating mobile authorization URL:", error);
      res.status(500).json({
        error: "Failed to generate mobile authorization URL",
        details: error instanceof Error ? error.message : String(error),
      });
    }
  });

  app.get("/api/oauth/callback", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");

    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }

    try {
      console.log("[OAuth] Processing callback with code and state");
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      await syncUser(userInfo);
      const sessionToken = await sdk.createSessionToken(userInfo.openId!, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      // Determine redirect based on request origin
      // If coming from mobile app (deep link), redirect to deep link with token
      // If coming from web, redirect to frontend URL
      const origin = req.get("origin") || req.get("referer") || "";
      const isMobileRequest = origin.includes("manus") || req.query.platform === "mobile";
      
      if (isMobileRequest) {
        // For mobile: redirect to deep link with token
        const deepLinkScheme = process.env.GOOGLE_REDIRECT_URI_MOBILE || "manus20260215181436://oauth/callback";
        const deepLinkUrl = `${deepLinkScheme}?token=${encodeURIComponent(sessionToken)}`;
        console.log("[OAuth] Redirecting to mobile deep link:", deepLinkUrl);
        res.redirect(302, deepLinkUrl);
      } else {
        // For web: redirect to frontend URL with cookie
        const frontendUrl =
          process.env.EXPO_WEB_PREVIEW_URL ||
          process.env.EXPO_PACKAGER_PROXY_URL ||
          "http://localhost:8081";
        console.log("[OAuth] Redirecting to web frontend:", frontendUrl);
        res.redirect(302, frontendUrl);
      }
    } catch (error) {
      console.error("[OAuth] Callback failed", error);
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });

  app.get("/api/oauth/mobile", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");

    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }

    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      const user = await syncUser(userInfo);

      const sessionToken = await sdk.createSessionToken(userInfo.openId!, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      res.json({
        app_session_id: sessionToken,
        user: buildUserResponse(user),
      });
    } catch (error) {
      console.error("[OAuth] Mobile exchange failed", error);
      res.status(500).json({ error: "OAuth mobile exchange failed" });
    }
  });

  app.post("/api/auth/logout", async (req: Request, res: Response) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (user?.id) {
        console.log(`[Auth] Revoking all tokens for user ${user.id}`);
        await refreshTokenService.revokeAllUserTokens(user.id, "USER_LOGOUT");
      }
      const cookieOptions = getSessionCookieOptions(req);
      res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      res.status(204).send();
    } catch (error) {
      console.error("[Auth] Logout failed:", error);
      const cookieOptions = getSessionCookieOptions(req);
      res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      res.status(204).send();
    }
  });

  // Get current authenticated user - works with both cookie (web) and Bearer token (mobile)
  app.get("/api/auth/me", async (req: Request, res: Response) => {
    try {
      const user = await sdk.authenticateRequest(req);
      res.json({ user: buildUserResponse(user) });
    } catch (error) {
      console.error("[Auth] /api/auth/me failed:", error);
      res.status(401).json({ error: "Not authenticated", user: null });
    }
  });

  // Refresh access token using refresh token
  app.post("/api/auth/refresh", async (req: Request, res: Response) => {
    try {
      console.log("[Auth] Refresh token request");

      // Get refresh token from cookie or Authorization header
      const refreshTokenCookie = req.cookies[COOKIE_NAME + "_refresh"];
      const authHeader = req.headers.authorization || req.headers.Authorization;
      const refreshTokenFromHeader = authHeader
        ? (typeof authHeader === "string" && authHeader.startsWith("Bearer "))
          ? authHeader.slice("Bearer ".length).trim()
          : undefined
        : undefined;

      const refreshToken = refreshTokenCookie || refreshTokenFromHeader;

      if (!refreshToken) {
        console.warn("[Auth] Refresh token missing");
        res.status(401).json({ error: "Refresh token required" });
        return;
      }

      // Valida e rotaciona o refresh token
      const payload = await refreshTokenService.validateRefreshToken(refreshToken);

      if (!payload) {
        console.warn("[Auth] Refresh token validation failed");
        res.status(401).json({ error: "Invalid or expired refresh token" });
        return;
      }

      // Busca o usuário
      const user = await sdk.authenticateRequest(req);

      if (!user || user.openId !== payload.userId.toString()) {
        console.warn("[Auth] User mismatch in refresh token");
        res.status(401).json({ error: "User mismatch" });
        return;
      }

      // Gera novo access token
      const newAccessToken = await sdk.createSessionToken(user.openId, {
        name: user.name || "",
        expiresInMs: 15 * 60 * 1000, // 15 minutos
      });

      // Rotaciona o refresh token
      const rotatedToken = await refreshTokenService.rotateRefreshToken(
        refreshToken,
        payload.userId,
      );

      if (!rotatedToken) {
        console.error("[Auth] Failed to rotate refresh token");
        res.status(500).json({ error: "Token rotation failed" });
        return;
      }

      // Seta novo refresh token no cookie
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME + "_refresh", rotatedToken.newToken, {
        ...cookieOptions,
        maxAge: rotatedToken.expiresAt.getTime() - Date.now(),
      });

      console.log(`[Auth] Refresh token rotated successfully for user ${payload.userId}`);

      // Retorna apenas o novo access token
      res.json({
        accessToken: newAccessToken,
        expiresIn: 15 * 60, // 15 minutos em segundos
      });
    } catch (error) {
      console.error("[Auth] Refresh token error:", error);
      res.status(500).json({ error: "Token refresh failed" });
    }
  });

  // Establish session cookie from Bearer token
  // Used by iframe preview: frontend receives token via postMessage, then calls this endpoint
  // to get a proper Set-Cookie response from the backend (3000-xxx domain)
  app.post("/api/auth/session", async (req: Request, res: Response) => {
    try {
      // Authenticate using Bearer token from Authorization header
      const user = await sdk.authenticateRequest(req);

      // Get the token from the Authorization header to set as cookie
      const authHeader = req.headers.authorization || req.headers.Authorization;
      if (typeof authHeader !== "string" || !authHeader.startsWith("Bearer ")) {
        res.status(400).json({ error: "Bearer token required" });
        return;
      }
      const token = authHeader.slice("Bearer ".length).trim();

      // Set cookie for this domain (3000-xxx)
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      res.json({ success: true, user: buildUserResponse(user) });
    } catch (error) {
      console.error("[Auth] /api/auth/session failed:", error);
      res.status(401).json({ error: "Invalid token" });
    }
  });
}
