# 🔍 PRODUCTION DIAGNOSTICS & DEPLOYMENT GUIDE

**Objetivo:** Diagnosticar e padronizar o deploy da aplicação em produção  
**Status:** 📋 Guia de Referência  
**Data:** 2026-02-22

---

## 📊 SITUAÇÃO ATUAL

### Problema Identificado
- ❌ Endpoints OAuth retornando `{"status":"not found"}` em produção
- ❌ Todos os endpoints retornando 404 (não apenas OAuth)
- ❌ Ambiente de produção não documentado
- ❌ Pipeline de deploy desconhecido
- ❌ Commit em execução não confirmado

### Hipóteses
1. **Servidor diferente:** Produção pode estar usando proxy/gateway que não conhece as rotas
2. **Build desatualizado:** Pode estar usando build anterior ao commit com OAuth
3. **Configuração incorreta:** Variáveis de ambiente podem não estar injetadas
4. **Deploy manual:** Sem CI/CD, difícil rastrear qual versão está rodando

---

## 🔧 FASE 1: DIAGNÓSTICO DO AMBIENTE

### 1.1 Identificar o Servidor em Produção

**Teste 1: Verificar resposta do servidor**
```bash
curl -v https://api.manus.im/
```

**Esperado:**
- Express: `Cannot GET /` (HTML)
- Next.js: Página Next.js
- Outro: Resposta específica

**Teste 2: Verificar headers HTTP**
```bash
curl -i https://api.manus.im/ | grep -E "Server|X-Powered-By"
```

**Esperado:**
- Express: `Server: Express` ou similar
- Informações sobre o framework

**Teste 3: Verificar porta e protocolo**
```bash
curl -v https://api.manus.im/api/health
```

**Esperado:**
- Resposta do servidor (200, 404, 500, etc.)
- Headers indicando tipo de servidor

### 1.2 Verificar Commit em Produção

**Teste 4: Endpoint de versão (se existir)**
```bash
curl https://api.manus.im/api/version
curl https://api.manus.im/api/info
curl https://api.manus.im/version.json
```

**Teste 5: Verificar logs do servidor**
```bash
# SSH para servidor de produção
ssh user@api.manus.im

# Verificar logs
tail -100 /var/log/app.log
tail -100 /var/log/docker.log
journalctl -u app-service -n 100
```

### 1.3 Verificar Build em Produção

**Teste 6: Verificar arquivo de build**
```bash
# SSH para servidor
ssh user@api.manus.im

# Verificar se existe dist/
ls -la /app/dist/
ls -la /app/build/
ls -la /app/.next/

# Verificar timestamp do build
stat /app/dist/index.js | grep Modify
```

**Teste 7: Verificar variáveis de ambiente**
```bash
# SSH para servidor
ssh user@api.manus.im

# Verificar .env
cat /app/.env | grep GOOGLE_CLIENT

# Verificar variáveis do processo
ps aux | grep node
```

### 1.4 Verificar Pipeline de Deploy

**Teste 8: Verificar se existe CI/CD**
```bash
# Verificar GitHub Actions
ls -la .github/workflows/

# Verificar GitLab CI
cat .gitlab-ci.yml

# Verificar Jenkins
cat Jenkinsfile

# Verificar Docker
cat Dockerfile
cat docker-compose.yml
```

**Teste 9: Verificar histórico de deploy**
```bash
# SSH para servidor
ssh user@api.manus.im

# Verificar histórico de git
cd /app && git log --oneline -10

# Verificar data do último deploy
ls -la /app/dist/ | head -5
```

---

## 🛠️ FASE 2: VALIDAÇÃO DO BUILD LOCAL

### 2.1 Build de Desenvolvimento

```bash
cd /home/ubuntu/driver-finance-app

# Limpar build anterior
rm -rf dist/

# Build
npm run build

# Verificar se foi criado
ls -la dist/
file dist/index.js
```

**Esperado:**
```
-rw-r--r-- 1 ubuntu ubuntu 123456 Feb 22 12:00 dist/index.js
```

### 2.2 Testar Build Localmente

```bash
# Iniciar servidor com build
NODE_ENV=production node dist/index.js

# Em outro terminal, testar endpoints
curl http://localhost:3000/api/health
curl http://localhost:3000/api/auth/google/url
```

**Esperado:**
```json
{"ok":true,"timestamp":1645000000000}
{"url":"https://accounts.google.com/o/oauth2/v2/auth?..."}
```

### 2.3 Validar Variáveis de Ambiente

```bash
# Criar .env.production
cat > .env.production << 'EOF'
GOOGLE_CLIENT_ID_WEB=687561160795-jdsjgslgt6is16sl4qudrfiuccq7uo4k.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
GOOGLE_REDIRECT_URI=https://api.manus.im/api/oauth/callback
GOOGLE_REDIRECT_URI_MOBILE=manus20260215181436://oauth/callback
DATABASE_URL=postgresql://...
EOF

# Testar com variáveis
NODE_ENV=production $(cat .env.production | xargs) node dist/index.js
```

---

## 🐳 FASE 3: PADRONIZAR COM DOCKER

### 3.1 Criar Dockerfile

**Arquivo:** `Dockerfile`

```dockerfile
# Build stage
FROM node:22-alpine AS builder

WORKDIR /app

# Copiar package files
COPY package.json pnpm-lock.yaml ./

# Instalar dependências
RUN npm install -g pnpm && pnpm install --frozen-lockfile

# Copiar código
COPY . .

# Build
RUN npm run build

# Runtime stage
FROM node:22-alpine

WORKDIR /app

# Instalar apenas dependências de produção
COPY package.json pnpm-lock.yaml ./
RUN npm install -g pnpm && pnpm install --frozen-lockfile --prod

# Copiar build do stage anterior
COPY --from=builder /app/dist ./dist

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD node -e "require('http').get('http://localhost:3000/api/health', (r) => {if (r.statusCode !== 200) throw new Error(r.statusCode)})"

# Expor porta
EXPOSE 3000

# Start
CMD ["node", "dist/index.js"]
```

### 3.2 Criar docker-compose.yml

**Arquivo:** `docker-compose.yml`

```yaml
version: '3.8'

services:
  api:
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - "3000:3000"
    environment:
      NODE_ENV: production
      PORT: 3000
      GOOGLE_CLIENT_ID_WEB: ${GOOGLE_CLIENT_ID_WEB}
      GOOGLE_CLIENT_SECRET: ${GOOGLE_CLIENT_SECRET}
      GOOGLE_REDIRECT_URI: ${GOOGLE_REDIRECT_URI}
      GOOGLE_REDIRECT_URI_MOBILE: ${GOOGLE_REDIRECT_URI_MOBILE}
      DATABASE_URL: ${DATABASE_URL}
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/health"]
      interval: 30s
      timeout: 3s
      retries: 3
      start_period: 5s
    volumes:
      - ./logs:/app/logs
    networks:
      - app-network

  # Nginx reverse proxy (opcional)
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - api
    networks:
      - app-network

networks:
  app-network:
    driver: bridge
```

### 3.3 Criar .dockerignore

**Arquivo:** `.dockerignore`

```
node_modules
npm-debug.log
dist
.git
.gitignore
README.md
.env
.env.local
.DS_Store
coverage
.expo
.next
build
```

---

## 📝 FASE 4: CRIAR SCRIPTS DE DEPLOY

### 4.1 Script de Build

**Arquivo:** `scripts/build.sh`

```bash
#!/bin/bash
set -e

echo "🔨 Building application..."

# Limpar build anterior
rm -rf dist/

# Instalar dependências
npm ci

# Build
npm run build

# Validar build
if [ ! -f "dist/index.js" ]; then
  echo "❌ Build failed: dist/index.js not found"
  exit 1
fi

echo "✅ Build successful"
echo "📦 Build size: $(du -sh dist/ | cut -f1)"
```

### 4.2 Script de Deploy

**Arquivo:** `scripts/deploy.sh`

```bash
#!/bin/bash
set -e

ENVIRONMENT=${1:-production}
COMMIT=$(git rev-parse --short HEAD)
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo "🚀 Deploying to $ENVIRONMENT (commit: $COMMIT)"

# Build
./scripts/build.sh

# Create deployment package
DEPLOY_DIR="deploy_${TIMESTAMP}_${COMMIT}"
mkdir -p "$DEPLOY_DIR"
cp -r dist/ "$DEPLOY_DIR/"
cp package.json pnpm-lock.yaml "$DEPLOY_DIR/"
cp .env.${ENVIRONMENT} "$DEPLOY_DIR/.env" || echo "⚠️  No .env.${ENVIRONMENT} found"

# Compress
tar -czf "${DEPLOY_DIR}.tar.gz" "$DEPLOY_DIR"

echo "✅ Deployment package ready: ${DEPLOY_DIR}.tar.gz"
echo "📦 Size: $(du -sh ${DEPLOY_DIR}.tar.gz | cut -f1)"

# Upload to server (example)
# scp "${DEPLOY_DIR}.tar.gz" deploy@api.manus.im:/tmp/
# ssh deploy@api.manus.im "cd /app && tar -xzf /tmp/${DEPLOY_DIR}.tar.gz && ./scripts/install.sh"

echo "📋 Next steps:"
echo "1. Upload: scp ${DEPLOY_DIR}.tar.gz deploy@api.manus.im:/tmp/"
echo "2. Extract: ssh deploy@api.manus.im 'cd /app && tar -xzf /tmp/${DEPLOY_DIR}.tar.gz'"
echo "3. Restart: ssh deploy@api.manus.im 'systemctl restart app'"
```

### 4.3 Script de Validação Pós-Deploy

**Arquivo:** `scripts/validate-deployment.sh`

```bash
#!/bin/bash
set -e

API_URL=${1:-https://api.manus.im}
MAX_RETRIES=30
RETRY_INTERVAL=2

echo "🔍 Validating deployment at $API_URL"

# Retry logic
for i in $(seq 1 $MAX_RETRIES); do
  echo "Attempt $i/$MAX_RETRIES..."
  
  # Test health endpoint
  HEALTH=$(curl -s "$API_URL/api/health" | jq -r '.ok // false')
  
  if [ "$HEALTH" = "true" ]; then
    echo "✅ Health check passed"
    break
  fi
  
  if [ $i -eq $MAX_RETRIES ]; then
    echo "❌ Health check failed after $MAX_RETRIES attempts"
    exit 1
  fi
  
  sleep $RETRY_INTERVAL
done

# Test OAuth endpoints
echo "Testing OAuth endpoints..."

OAUTH_URL=$(curl -s "$API_URL/api/auth/google/url" | jq -r '.url // empty')
if [ -z "$OAUTH_URL" ]; then
  echo "❌ OAuth URL endpoint failed"
  exit 1
fi
echo "✅ OAuth URL endpoint working"

OAUTH_MOBILE=$(curl -s "$API_URL/api/auth/google/url/mobile" | jq -r '.url // empty')
if [ -z "$OAUTH_MOBILE" ]; then
  echo "❌ OAuth mobile endpoint failed"
  exit 1
fi
echo "✅ OAuth mobile endpoint working"

# Test TRPC endpoint
TRPC_HEALTH=$(curl -s "$API_URL/api/trpc/health" | jq -r '.result.data.ok // false')
if [ "$TRPC_HEALTH" = "true" ]; then
  echo "✅ TRPC endpoint working"
else
  echo "⚠️  TRPC endpoint returned unexpected response"
fi

echo ""
echo "✅ All validation checks passed!"
echo "🎉 Deployment successful!"
```

---

## 📋 FASE 5: CHECKLIST DE DEPLOY

### Pré-Deploy
- [ ] Código commitado e pushed
- [ ] Testes passando: `npm test`
- [ ] Build local validado: `npm run build`
- [ ] Variáveis de ambiente configuradas
- [ ] Nenhum erro de TypeScript: `npm run check`

### Deploy
- [ ] Backup do servidor anterior
- [ ] Build criado: `npm run build`
- [ ] Variáveis de ambiente injetadas
- [ ] Dependências instaladas: `npm ci --prod`
- [ ] Servidor iniciado

### Pós-Deploy
- [ ] Health check: `GET /api/health` → 200
- [ ] OAuth endpoints: `GET /api/auth/google/url` → 200
- [ ] Logs sem erros: `tail -100 /var/log/app.log`
- [ ] Commit verificado: `curl https://api.manus.im/api/version`
- [ ] Testes de smoke: Login, OAuth, Dashboard

---

## 🔗 REFERÊNCIAS RÁPIDAS

### Comandos de Diagnóstico

```bash
# Verificar se servidor está rodando
curl -v https://api.manus.im/

# Verificar health
curl https://api.manus.im/api/health

# Verificar OAuth
curl https://api.manus.im/api/auth/google/url

# Verificar logs (SSH)
ssh user@api.manus.im tail -100 /var/log/app.log

# Verificar processo (SSH)
ssh user@api.manus.im ps aux | grep node

# Verificar porta (SSH)
ssh user@api.manus.im netstat -tlnp | grep 3000
```

### Variáveis de Ambiente Obrigatórias

```
GOOGLE_CLIENT_ID_WEB=687561160795-jdsjgslgt6is16sl4qudrfiuccq7uo4k.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
GOOGLE_REDIRECT_URI=https://api.manus.im/api/oauth/callback
GOOGLE_REDIRECT_URI_MOBILE=manus20260215181436://oauth/callback
DATABASE_URL=postgresql://...
NODE_ENV=production
PORT=3000
```

---

## 🎯 PRÓXIMOS PASSOS

1. **Executar diagnóstico:**
   ```bash
   # Teste 1-4: Identificar servidor
   curl -v https://api.manus.im/
   
   # Teste 5-7: Verificar logs e build
   ssh user@api.manus.im
   ```

2. **Implementar Docker:**
   ```bash
   # Testar localmente
   docker-compose up
   curl http://localhost:3000/api/health
   ```

3. **Automatizar deploy:**
   ```bash
   # Usar scripts
   ./scripts/build.sh
   ./scripts/deploy.sh production
   ./scripts/validate-deployment.sh https://api.manus.im
   ```

4. **Documentar ambiente:**
   - Criar `DEPLOYMENT.md` com instruções específicas
   - Documentar servidor, pipeline, variáveis
   - Criar runbook de troubleshooting

---

**Preparado por:** Manus AI  
**Data:** 2026-02-22  
**Status:** 📋 Guia de Referência

