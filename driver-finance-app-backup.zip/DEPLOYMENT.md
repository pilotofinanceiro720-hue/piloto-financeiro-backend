# 🚀 DEPLOYMENT GUIDE

**Objetivo:** Instruções passo-a-passo para deploy em produção  
**Última atualização:** 2026-02-22

---

## 📋 PRÉ-REQUISITOS

### Ambiente Local
- Node.js 22+
- npm/pnpm
- Docker & Docker Compose (para containerização)
- Git

### Ambiente de Produção
- Servidor Linux (Ubuntu 22.04 recomendado)
- Docker & Docker Compose instalados
- Acesso SSH ao servidor
- Domínio configurado (api.manus.im)
- SSL/TLS certificado

---

## 🔧 FASE 1: PREPARAÇÃO LOCAL

### 1.1 Clonar Repositório

```bash
git clone https://github.com/seu-usuario/driver-finance-app.git
cd driver-finance-app
```

### 1.2 Instalar Dependências

```bash
npm ci
```

### 1.3 Validar Build

```bash
# Executar validação completa
chmod +x scripts/validate-build.sh
./scripts/validate-build.sh
```

**Esperado:**
```
✅ BUILD VALIDATION COMPLETE
Summary:
  • Node.js: v22.x.x
  • npm: 10.x.x
  • Build size: 50M
  • Commit: abc1234
  • Branch: main
```

---

## 🐳 FASE 2: CONTAINERIZAÇÃO (DOCKER)

### 2.1 Testar Localmente com Docker

```bash
# Build image
docker build -t driver-finance-api:latest .

# Verificar imagem
docker images | grep driver-finance

# Executar container
docker run -p 3000:3000 \
  -e GOOGLE_CLIENT_ID_WEB=687561160795-... \
  -e GOOGLE_CLIENT_SECRET=GOCSPX-... \
  -e GOOGLE_REDIRECT_URI=https://api.manus.im/api/oauth/callback \
  -e GOOGLE_REDIRECT_URI_MOBILE=manus20260215181436://oauth/callback \
  driver-finance-api:latest

# Testar em outro terminal
curl http://localhost:3000/api/health
```

### 2.2 Testar com Docker Compose

```bash
# Criar .env.local para desenvolvimento
cat > .env.local << 'EOF'
NODE_ENV=development
GOOGLE_CLIENT_ID_WEB=687561160795-jdsjgslgt6is16sl4qudrfiuccq7uo4k.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
GOOGLE_REDIRECT_URI=http://localhost:3000/api/oauth/callback
GOOGLE_REDIRECT_URI_MOBILE=manus20260215181436://oauth/callback
DATABASE_URL=postgresql://postgres:postgres@db:5432/driver_finance
DB_USER=postgres
DB_PASSWORD=postgres
DB_NAME=driver_finance
EOF

# Iniciar stack
docker-compose up -d

# Verificar logs
docker-compose logs -f api

# Testar endpoints
curl http://localhost:3000/api/health
curl http://localhost:3000/api/auth/google/url

# Parar stack
docker-compose down
```

---

## 📤 FASE 3: DEPLOY PARA PRODUÇÃO

### 3.1 Preparar Servidor de Produção

```bash
# SSH para servidor
ssh deploy@api.manus.im

# Criar diretório de aplicação
mkdir -p /app/driver-finance
cd /app/driver-finance

# Clonar repositório
git clone https://github.com/seu-usuario/driver-finance-app.git .

# Criar .env.production com valores reais
cat > .env.production << 'EOF'
NODE_ENV=production
PORT=3000
GOOGLE_CLIENT_ID_WEB=687561160795-jdsjgslgt6is16sl4qudrfiuccq7uo4k.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
GOOGLE_REDIRECT_URI=https://api.manus.im/api/oauth/callback
GOOGLE_REDIRECT_URI_MOBILE=manus20260215181436://oauth/callback
DATABASE_URL=postgresql://prod_user:prod_password@db:5432/driver_finance
DB_USER=prod_user
DB_PASSWORD=prod_password
DB_NAME=driver_finance
EOF

# Proteger arquivo .env
chmod 600 .env.production
```

### 3.2 Iniciar Aplicação em Produção

```bash
# SSH para servidor
ssh deploy@api.manus.im
cd /app/driver-finance

# Carregar variáveis de ambiente
export $(cat .env.production | xargs)

# Iniciar com Docker Compose
docker-compose --profile production up -d

# Verificar status
docker-compose ps

# Verificar logs
docker-compose logs -f api
```

### 3.3 Configurar Nginx (Reverse Proxy)

**Arquivo:** `/app/driver-finance/nginx.conf`

```nginx
upstream api {
  server api:3000;
}

server {
  listen 80;
  server_name api.manus.im;
  
  # Redirect HTTP to HTTPS
  return 301 https://$server_name$request_uri;
}

server {
  listen 443 ssl http2;
  server_name api.manus.im;

  # SSL certificates
  ssl_certificate /etc/nginx/ssl/cert.pem;
  ssl_certificate_key /etc/nginx/ssl/key.pem;

  # SSL configuration
  ssl_protocols TLSv1.2 TLSv1.3;
  ssl_ciphers HIGH:!aNULL:!MD5;
  ssl_prefer_server_ciphers on;

  # Proxy settings
  location / {
    proxy_pass http://api;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_cache_bypass $http_upgrade;
    
    # Timeouts
    proxy_connect_timeout 60s;
    proxy_send_timeout 60s;
    proxy_read_timeout 60s;
  }

  # Health check endpoint
  location /api/health {
    proxy_pass http://api;
    access_log off;
  }
}
```

### 3.4 Validar Deploy

```bash
# SSH para servidor
ssh deploy@api.manus.im

# Executar validação
cd /app/driver-finance
chmod +x scripts/validate-deployment.sh
./scripts/validate-deployment.sh https://api.manus.im
```

**Esperado:**
```
✅ Health check passed
✅ OAuth URL endpoint working
✅ OAuth mobile endpoint working
✅ TRPC endpoint working
✅ All validation checks passed!
🎉 Deployment successful!
```

---

## 📊 FASE 4: MONITORAMENTO PÓS-DEPLOY

### 4.1 Verificar Status

```bash
# SSH para servidor
ssh deploy@api.manus.im

# Verificar containers
docker-compose ps

# Verificar logs
docker-compose logs api | tail -50

# Verificar recursos
docker stats

# Verificar portas
netstat -tlnp | grep 3000
```

### 4.2 Testar Endpoints

```bash
# Health
curl https://api.manus.im/api/health

# OAuth
curl https://api.manus.im/api/auth/google/url

# OAuth Mobile
curl https://api.manus.im/api/auth/google/url/mobile

# TRPC
curl https://api.manus.im/api/trpc/health
```

### 4.3 Monitorar Logs

```bash
# SSH para servidor
ssh deploy@api.manus.im

# Logs em tempo real
docker-compose logs -f api

# Filtrar por erro
docker-compose logs api | grep ERROR

# Filtrar por OAuth
docker-compose logs api | grep OAuth
```

---

## 🔄 FASE 5: ATUALIZAÇÕES FUTURAS

### 5.1 Deploy de Nova Versão

```bash
# Local: Commit e push
git add .
git commit -m "feat: nova funcionalidade"
git push origin main

# Servidor: Pull e redeploy
ssh deploy@api.manus.im
cd /app/driver-finance
git pull origin main
docker-compose down
docker-compose up -d --build
```

### 5.2 Rollback para Versão Anterior

```bash
# Servidor: Voltar para commit anterior
ssh deploy@api.manus.im
cd /app/driver-finance
git revert HEAD
docker-compose down
docker-compose up -d --build
```

---

## 🆘 TROUBLESHOOTING

### Problema: Endpoints retornam 404

**Causa possível:** Build desatualizado

**Solução:**
```bash
# Verificar commit
curl https://api.manus.im/api/version

# Verificar logs
docker-compose logs api | grep OAuth

# Reconstruir
docker-compose down
docker-compose up -d --build
```

### Problema: Variáveis de ambiente não injetadas

**Causa possível:** .env.production não carregado

**Solução:**
```bash
# Verificar arquivo
cat .env.production

# Verificar variáveis no container
docker exec driver-finance-api env | grep GOOGLE

# Reiniciar com variáveis
docker-compose down
export $(cat .env.production | xargs)
docker-compose up -d
```

### Problema: Banco de dados não conecta

**Causa possível:** DATABASE_URL incorreta

**Solução:**
```bash
# Verificar conexão
docker exec driver-finance-db psql -U postgres -c "SELECT 1"

# Verificar logs do DB
docker-compose logs db

# Reiniciar DB
docker-compose restart db
```

---

## 📋 CHECKLIST DE DEPLOY

### Pré-Deploy
- [ ] Código commitado: `git status`
- [ ] Testes passando: `npm test`
- [ ] Build validado: `./scripts/validate-build.sh`
- [ ] Nenhum erro TypeScript: `npm run check`
- [ ] Variáveis de ambiente configuradas
- [ ] Backup do banco de dados

### Deploy
- [ ] SSH acesso ao servidor
- [ ] Repositório clonado
- [ ] .env.production criado
- [ ] Docker Compose iniciado
- [ ] Nginx configurado
- [ ] SSL certificado instalado

### Pós-Deploy
- [ ] Health check: `curl https://api.manus.im/api/health`
- [ ] OAuth endpoints: `curl https://api.manus.im/api/auth/google/url`
- [ ] Logs sem erros: `docker-compose logs api`
- [ ] Commit verificado
- [ ] Testes de smoke (login, OAuth, dashboard)
- [ ] Monitoramento ativo

---

## 📞 SUPORTE

Para problemas:

1. Verificar logs: `docker-compose logs api`
2. Executar diagnóstico: `./scripts/validate-deployment.sh`
3. Consultar guia de diagnóstico: `PRODUCTION_DIAGNOSTICS_GUIDE.md`

---

**Preparado por:** Manus AI  
**Data:** 2026-02-22  
**Versão:** 1.0

